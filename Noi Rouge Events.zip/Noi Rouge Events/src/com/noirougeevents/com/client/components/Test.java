/**
 * 
 */
package com.noirougeevents.com.client.components;

/**
 * @author RynoM
 *
 */
public class Test
{
	/**
	 * @param name
	 * @return String
	 */
	public String SayHello(String name)
	{
		return "Hello " + name;
	}
}
